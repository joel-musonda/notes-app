# Notes App

A Pen created on CodePen.io. Original URL: [https://codepen.io/Joel-Musonda/pen/MWxbmbG](https://codepen.io/Joel-Musonda/pen/MWxbmbG).

A react app that allows users to make notes and also delete them 