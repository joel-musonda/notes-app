const App = () => {
  const [notes, setNotes] = React.useState([]);
  const [inputvalue, setInputvalue] = React.useState("");
  const [searchitem, setSearchItem] = React.useState("");

  function HandleTextChange(e) {
    setInputvalue(e.target.value);
  }
  function HandleAddNote(e) {
    e.preventDefault();
    setNotes([...notes, inputvalue]);
    setInputvalue("");
  }
  function handlesearch() {
    setNotes(
      notes.filter((notes) =>
        notes.text.toLowerCase().includes(searchitem.toLowerCase())
      )
    );
  }

  const Title = "Notes App";
  return (
    <div className="app">
      <span className="title">{Title}</span>
      <div className="search-bar">
        <input
          value={searchitem}
          onChange={(e) => setSearchItem(e.target.value)}
          placeholder="Search notes..."
          rows={3}
          className="text-area"
        />
        <button onChange={handlesearch}>Search</button>
      </div>
      <div className="note-box">
        <div className="note-box-right">
          <textarea
            placeholder="Enter your note here...."
            rows={5}
            className="notes-text-area"
            value={inputvalue}
            onChange={HandleTextChange}
          />
          <div className="color-picker">
            <input type="radio" name="color-pick" value="#F06292" id="color1" />
            <label
              htmlFor="color1"
              style={{ backgroundColor: "#F06292" }}
            ></label>
            <input type="radio" name="color-pick" value="#BA68C8" id="color2" />
            <label
              htmlFor="color2"
              style={{ backgroundColor: "#BA68C8" }}
            ></label>
            <input type="radio" name="color-pick" value="#FFD54F" id="color3" />
            <label
              htmlFor="color3"
              style={{ backgroundColor: "#FFD54F" }}
            ></label>
            <input type="radio" name="color-pick" value="#4FC3F7" id="color4" />
            <label
              htmlFor="color4"
              style={{ backgroundColor: "#4FC3F7" }}
            ></label>
            <input type="radio" name="color-pick" value="#AED581" id="color5" />
            <label
              htmlFor="color5"
              style={{ backgroundColor: "#AED581" }}
            ></label>
          </div>
          <button className="add-button" onClick={HandleAddNote}>
            Add Note
          </button>
        </div>
        <div className="note-box-left">
          <ul>
            {notes.map((note) => (
              <p key={note}>
                {note} <button>Delete</button>
              </p>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
// Render root components
ReactDOM.render(<App />, document.getElementById("root"));
